#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
int main(){
	int pid=0, status = 0;
	pid = fork();
	if (pid == -1){
		printf("Error");
		exit(1);
	}
	if (pid == 0) {
		if (execl("/bin/ls","/bin/ls","-l","-a",NULL) == -1)
			printf("Error\n");
	}
	else {
		wait(&status);
		printf("El proceso hijo ha  finalizado con estado %d \n",status);
	}

}


